package assesment_03_and_04;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList; 

public class session_03_and_04 {

	public static void main(String[] args) {
		ArrayList<FlightStruct> flightList = createFlightFromCSVFile("flights.csv");
		printFlights(flightList);
	}
	/*
	 public static void readAndPrintCSVFile(string fileName){
	 	String dir = System.getProperty("user.dir");
	 	System.out.println(dir);
	 	try{
	 		BufferedReader reader = new BufferedReader(new FileReader(FileName));
	 		String firstLine =reader.readLline();
	 		System.out.println(firstLine);
	 		String Line;
	 		while((line = reader.readLine())!=null){
	 			System.out.println(line);
	 			String[] fields =line.split(",");
	 			for(String field + fields){
	 			 	System.out.println(field);
	 			}
	 		}
	 		reader.close();
	 	}catch(Exception e){
	 		System.out.printlm(e);
	 	}
	 }
	 */

	public static ArrayList<FlightStruct> createFlightListFromCSVFile(String fileName){
	
		ArrayList<flightStruct> flights = new ArrayList<>();
			try {
				BufferedReader reader = new BufferedReader(new FileReader(fileName));
				String firstLine = reader.readLine();
				System.out.println(firstLine);
				String line;
				int line_no =2;
				while((line =reader.readLine())!=null) {
					String[] record =line.split(",");
					processFlightInfo(line_no, line, record, flights );
					line_no++;
				}
				reader.close();
				return flights;
			}catch (Exception e) {
				System.out.println(e);
				return null;
			}
	}
	
	static void processFlightInfo(int line_no, String line, String[] record, ArrayList<FlightStruct>flights) {
		
		ArrayList<String> errors =validateCSVRecord(line_no,line,record);
		
		if(errors.size()==0) {
			FlightStruct flight=createFlightCSVRecord(record);
			ArrayList<String> flightErrors = validateFlightData(line_no,line,flight);
			if(flightErrors.size()==0) {
				flights.add(flight);
			}
			else {
				printErrors(flightErrors);
			}
		}
		else {
			printErrors(errors);
		}
	}
	
	private static void printErrors(ArrayList<String> errors) {
}



















