package assesment_02;

import java.util.*;

public class Example {

	public static void main(String[] args) {
		
		int first = getFirstNumberFromUser();
		int second = getSecondNumberFromUser();
		
		int result= compute(first,second);
		output(result);
		
	}
	
	private static int getFirstNumberFromUser() {
		return getInputFromUser("enter first number");
	}
	
	private static int getSecondNumberFromUser() {
		return getInputFromUser("enter second number");
	}
	private static int getInputFromUser(String prompt) {
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println(prompt);
			String input = sc.nextLine();
			if(input=="/q"){
				System.exit(0);
			}
			try {
				return Integer.parseInt(input);
			}catch(Exception e) {
				System.out.println("enter valid number");
			}
		}
	}
	
	private static int compute(int n1, int n2) {
		return n1+n2;
	}
	
	private static void output(int output) {
		System.out.println("result= "+output);
	}
	
}
