package assesment_02;

import java.util.*;

public class Flights_selector {

	public static void main(String[] args) {
		
		String departureCity=getDeparture();
		String destinationCity=getDestination();
		
		while(departureCity.equals(destinationCity)) {
			System.out.println("Departure and destination cities cannot be the same. Please enter again.");
			departureCity=getDeparture();
			destinationCity=getDestination();
		}
	}
	private static String getDeparture() {
		return getInputFromUser("enter departure city ");
	}
	
	private static String getDestination() {
		return getInputFromUser("enter destination city ");
	}
	
	private static String getInputFromUser(String prompt) {
		String[] cities = {"delhi","kolkata","pune","mumbai","hyderabad","jaipur","luckhnow","kanpur","jamshedpur","kanpur"};
		Scanner sc= new Scanner(System.in);
		while(true) {
			System.out.println("cities list: "+Arrays.toString(cities));
			System.out.println(prompt);
			String input = sc.nextLine();
			if(input.equalsIgnoreCase("/q")) {
				System.exit(0);
			}
			if(checkValidCity(input, cities)) {
				return input;
			} else {
				System.out.println("Invalid city. Please enter a valid city from the list: " + Arrays.toString(cities));
			}
		}
	}
	
	private static boolean checkValidCity(String city, String[] cities) {
		for(String c : cities) {
			if(c.equalsIgnoreCase(city)) {
				return true;
			}
		}
		return false;
	}
}



