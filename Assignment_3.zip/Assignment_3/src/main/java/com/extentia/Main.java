package com.extentia;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
//		ArrayList<UserRecord>recordList= User.createRecordListFromCSV(null;)
		User.execute(args);
		
	}
}
