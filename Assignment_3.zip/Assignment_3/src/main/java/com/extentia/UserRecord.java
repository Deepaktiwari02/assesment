package com.extentia;

public class UserRecord {

	private String firstName;
	private String lastName;
	private String email;
	private long phone;
	private String city;

	public UserRecord(String firstName, String lastName, String email, long phone, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.city = city;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getEmail() {
		return email;
	}

	public long getPhone() {
		return phone;
	}

	public String getCity() {
		return city;
	}
	
	

}
