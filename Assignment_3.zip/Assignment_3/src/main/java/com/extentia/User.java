package com.extentia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class User {

	public static void execute(String[] args) {
		ArrayList<UserRecord> recordListFromCSV = createRecordListFromCSV("D:\\CSVFiles\\User.csv");
		printRecords(recordListFromCSV);
	}
	public static ArrayList<UserRecord> createRecordListFromCSV(String filename)
	{
		ArrayList<UserRecord> records =new ArrayList<>();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(filename));
			String firstLine=reader.readLine();
			System.out.println(firstLine);
			String line;
			
			while((line=reader.readLine())!=null)
			{
				String[] record=line.split(",");
				UserRecord record1=createRecordFromCSVRecord(record);
				records.add(record1);
			}
			reader.close();
			return records;
			
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}
	
	static UserRecord createRecordFromCSVRecord(String[] record)
	{
		String firstName=record[0];
		String lastName=record[1];
		String email=record[2];
		long phone=Long.parseLong(record[3]);
		String city=record[4];
		
		UserRecord recordFromCSV =new UserRecord(firstName, lastName, email, phone, city);
		return recordFromCSV;
	}
	
	static void printRecords(ArrayList<UserRecord>records)
	{
		for(UserRecord userRecord:records) {
			printSingleRecord(userRecord);
			System.out.println("------------------------------------------------");
		}
	}
	
	static void printSingleRecord(UserRecord record)
	{
		System.out.println("firstName: " + record.getFirstName());
		System.out.println("lastName: " + record.getLastName());
		System.out.println("email: "+ record.getEmail());
		System.out.println("phone: "+ record.getPhone());
		System.out.println("city: "+ record.getCity());
	}
}
